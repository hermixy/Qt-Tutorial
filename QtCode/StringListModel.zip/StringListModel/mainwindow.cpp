#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 初始化一个StringList字符串列表
    QStringList theStringList;
    theStringList << "北京" << "上海" << "广州";

    // 创建并使用数据模型
    model = new QStringListModel(this);     // 创建模型
    model->setStringList(theStringList);    // 导入模型数据

    ui->listView->setModel(model);          // 为listView设置模型
    ui->listView->setEditTriggers(QAbstractItemView::DoubleClicked |
                                  QAbstractItemView::SelectedClicked);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 添加一行
void MainWindow::on_btnListAppend_clicked()
{
    model->insertRow(model->rowCount());                       // 在尾部插入一行
    QModelIndex index = model->index(model->rowCount()-1,0);   // 获取最后一行的索引
    QString LineText = ui->lineEdit->text();
    model->setData(index,LineText,Qt::DisplayRole);            // 设置显示文字
    ui->listView->setCurrentIndex(index);                      // 设置当前行选中
    ui->lineEdit->clear();
}

// 插入一行数据到ListView
void MainWindow::on_btnListInsert_clicked()
{
    QModelIndex index;

    index= ui->listView->currentIndex();             // 获取当前选中行
    model->insertRow(index.row());                   // 在当前行的前面插入一行
    QString LineText = ui->lineEdit->text();
    model->setData(index,LineText,Qt::DisplayRole);             // 设置显示文字
    model->setData(index,Qt::AlignRight,Qt::TextAlignmentRole); // 设置对其方式
    ui->listView->setCurrentIndex(index);                       // 设置当前选中行
}

// 删除当前选中行
void MainWindow::on_btnListDelete_clicked()
{
    QModelIndex index;
    index = ui->listView->currentIndex();    // 获取当前行的ModelIndex
    model->removeRow(index.row());           // 删除选中行
}

// 清除当前列表
void MainWindow::on_btnListClear_clicked()
{
   model->removeRows(0,model->rowCount());
}

// 显示数据模型文本到QPlainTextEdit
void MainWindow::on_btnTextImport_clicked()
{
    QStringList pList;

    pList = model->stringList();    // 获取数据模型的StringList
    ui->plainTextEdit->clear();     // 先清空文本框

    // 循环追加数据
    for(int x=0;x< pList.count();x++)
    {
        ui->plainTextEdit->appendPlainText(pList.at(x) + QString(","));
    }
}

// 当ListView列表项被选中时，显示QModelIndex的行、列号
void MainWindow::on_listView_clicked(const QModelIndex &index)
{
        ui->LabInfo->setText(QString::asprintf("当前项:row=%d, column=%d",
                            index.row(),index.column()));
}
