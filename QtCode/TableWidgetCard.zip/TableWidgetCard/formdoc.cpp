#include "formdoc.h"
#include "ui_formdoc.h"
#include "mainwindow.h"

#include <QVBoxLayout>
#include <iostream>

FormDoc::FormDoc(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::FormDoc)
{
    ui->setupUi(this);

    QVBoxLayout *Layout = new QVBoxLayout();
    Layout->setContentsMargins(2,2,2,2);
    Layout->setSpacing(2);
    this->setLayout(Layout);

    MainWindow *parWind = (MainWindow*)parentWidget(); //获取父窗口指针
    QString ref = parWind->GetTableNumber();           // 获取选中标签索引
    std::cout << ref.toStdString().data() << std::endl;


}

FormDoc::~FormDoc()
{
    delete ui;
}
