#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tabWidget->setVisible(false);
    ui->tabWidget->clear();//清除所有页面
    ui->tabWidget->tabsClosable(); //Page有关闭按钮，可被关闭
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 定义函数来获取当前Table名字
QString MainWindow::GetTableNumber()
{
    QString ref = QString(ui->tabWidget->currentIndex());
    return ref;
}

void MainWindow::on_pushButton_clicked()
{
    FormDoc *ptr = new FormDoc(this);                // 新建选项卡
    ptr->setAttribute(Qt::WA_DeleteOnClose);         // 关闭时自动销毁

    int cur = ui->tabWidget->addTab(ptr,QString::asprintf(" 192.168.1.%d",ui->tabWidget->count()));

    ui->tabWidget->setTabIcon(cur,QIcon(":/image/1.ico"));

    ui->tabWidget->setCurrentIndex(cur);
    ui->tabWidget->setVisible(true);
}

// 关闭Tab时执行
void MainWindow::on_tabWidget_tabCloseRequested(int index)
{
    if (index<0)
        return;
    QWidget* aForm=ui->tabWidget->widget(index);
    aForm->close();
}

// 在无Tab页面是默认禁用
void MainWindow::on_tabWidget_currentChanged(int index)
{
    Q_UNUSED(index);
    bool en=ui->tabWidget->count()>0;
    ui->tabWidget->setVisible(en);
}
