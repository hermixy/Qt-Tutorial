#include "mainwindow.h"
#include "ui_mainwindow.h"

// 为一行的单元格创建 Items
void MainWindow::createItemsARow(int rowNo,QString Name,QString Sex,QDate birth,QString Nation,bool isPM,int score)
{
    QTableWidgetItem *item;
    QString str;
    uint StudID=1001; //学号基数

// 姓名
    //新建一个Item，设置单元格type为自定义的MainWindow::ctName
    item=new QTableWidgetItem(Name,MainWindow::ctName);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter); //文本对齐格式

    StudID  +=rowNo; //学号=基数+ 行号
    item->setData(Qt::UserRole,QVariant(StudID));  //设置studID为data
    ui->tableWidget->setItem(rowNo,MainWindow::colName,item); //为单元格设置Item

// 性别
    QIcon icon;
    if (Sex=="男")
        icon.addFile(":/image/boy.ico");
    else
        icon.addFile(":/image/girl.ico");

    item=new  QTableWidgetItem(Sex,MainWindow::ctSex); //新建一个Item，设置单元格type为自定义的 MainWindow::ctSex
    item->setIcon(icon);
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//为单元格设置Item
    ui->tableWidget->setItem(rowNo,MainWindow::colSex,item);//为单元格设置Item

//出生日期
    str=birth.toString("yyyy-MM-dd"); //日期转换为字符串
    item=new  QTableWidgetItem(str,MainWindow::ctBirth);//新建一个Item，设置单元格type为自定义的 MainWindow::ctBirth
    item->setTextAlignment(Qt::AlignLeft | Qt::AlignVCenter); //文本对齐格式
    ui->tableWidget->setItem(rowNo,MainWindow::colBirth,item);//为单元格设置Item

//民族
    item=new  QTableWidgetItem(Nation,MainWindow::ctNation); //新建一个Item，设置单元格type为自定义的 MainWindow::ctNation
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//文本对齐格式
    ui->tableWidget->setItem(rowNo,MainWindow::colNation,item);//为单元格设置Item

//是否党员
    item=new  QTableWidgetItem("群众",MainWindow::ctPartyM);//新建一个Item，设置单元格type为自定义的 MainWindow::ctPartyM
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//文本对齐格式
    if (isPM)
        item->setCheckState(Qt::Checked);
    else
        item->setCheckState(Qt::Unchecked);
    item->setBackgroundColor(Qt::yellow);                      // 设置为黄色
    ui->tableWidget->setItem(rowNo,MainWindow::colPartyM,item);//为单元格设置Item

//分数
    str.setNum(score);
    item=new  QTableWidgetItem(str,MainWindow::ctScore);//新建一个Item，设置单元格type为自定义的 MainWindow::ctPartyM
    item->setTextAlignment(Qt::AlignHCenter | Qt::AlignVCenter);//文本对齐格式
    ui->tableWidget->setItem(rowNo,MainWindow::colScore,item);//为单元格设置Item
}

// 构造函数
MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tableWidget->clear();

    // 设置表格默认不可编辑
    ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers);

    // 初始化状态栏
    labCellIndex = new QLabel("当前坐标: ",this);
    labCellIndex->setMinimumWidth(250);

    labCellType=new QLabel("单元格类型: ",this);
    labCellType->setMinimumWidth(200);

    labStudID=new QLabel("选中的ID: ",this);
    labStudID->setMinimumWidth(200);

    // 将初始化的标签添加到底部状态栏上
    ui->statusbar->addWidget(labCellIndex);
    ui->statusbar->addWidget(labCellType);
    ui->statusbar->addWidget(labStudID);
}

// 析构函数
MainWindow::~MainWindow()
{
    delete ui;
}

// 当前选择单元格发生变化时触发响应事件,也就是将底部状态栏标签设置
void MainWindow::on_tableWidget_currentCellChanged(int currentRow, int currentColumn, int previousRow, int previousColumn)
{
    Q_UNUSED(previousRow);
    Q_UNUSED(previousColumn);

    // 显示行与列的变化数值
    std::cout << "currentRow = " << currentRow << " currentColumn = " << currentColumn << std::endl;
    std::cout << "pre Row = " << previousRow << " pre Column = " << previousColumn << std::endl;

    // 获取当前单元格的Item
    QTableWidgetItem *item = ui->tableWidget->item(currentRow,currentColumn);
    if(item == NULL)
        return;

    // 设置单元格坐标
    labCellIndex->setText(QString::asprintf("当前坐标: %d 行 | %d 列",currentRow,currentColumn));

    // 设置单元格类型
    int cellType = item->type();
    labCellType->setText(QString::asprintf("单元格类型: %d",cellType));

    // 设置单元格选中学生的ID号
    item = ui->tableWidget->item(currentRow,MainWindow::colName);  // 取当前行第1列的单元格的item
    int ID = item->data(Qt::UserRole).toInt();                     // 读取用户自定义数据
    labStudID->setText(QString::asprintf("选中的ID: %d",ID));
}

// 设置表头的实现
void MainWindow::on_pushButton_clicked()
{
    QTableWidgetItem *headerItem;
    QStringList headerText_Row,headerText_Col;
    headerText_Row << "姓 名" << "性 别" << "出生日期" << "民 族" << "分数" << "是否党员";
    //headerText_Col << "第一行" << "第二行";

    // 设置为水平表头
    ui->tableWidget->setHorizontalHeaderLabels(headerText_Row);

    // 设置垂直表头
    //ui->tableWidget->setVerticalHeaderLabels(headerText_Col);

    // 另一种方式: 通过循环设置
    ui->tableWidget->setColumnCount(headerText_Row.count());       // 列数设置为与headerText_Row的列相等
    for (int i=0;i<ui->tableWidget->columnCount();i++)             // 列编号从0开始
    {
       headerItem=new QTableWidgetItem(headerText_Row.at(i));      // headerText.at(i) 获取headerText的i行字符串
       QFont font=headerItem->font();                              // 获取原有字体设置
       font.setBold(true);                                         // 设置为粗体
       font.setPointSize(8);                                       // 设置字体大小
       headerItem->setTextColor(Qt::black);                        // 设置字体颜色
       headerItem->setFont(font);                                  // 设置字体
       ui->tableWidget->setHorizontalHeaderItem(i,headerItem);     // 设置表头单元格的Item
    }
}

// 初始化表格元素
void MainWindow::on_pushButton_4_clicked()
{
    QString strName,strSex;
    bool isParty=false;

    QDate birth;
    birth.setDate(1997,10,7);                // 初始化一个日期
    ui->tableWidget->clearContents();        // 只清除工作区中的内容,不清除表格

    int Rows=ui->tableWidget->rowCount();    // 数据区行数

    // 循环添加行数据
    for (int i=0;i<Rows;i++)
    {
        strName=QString::asprintf("学生%d",i);  // 学生姓名
        if ((i % 2)==0)                         // 分奇数，偶数行设置性别，及其图标
            strSex="男";
        else
            strSex="女";

        createItemsARow(i, strName, strSex, birth,"汉族",isParty,70); //为某一行创建items

        birth=birth.addDays(20); //日期加20天
        isParty =!isParty;
    }
}

// 从spinBox中读出数量,并设置TableWidget表格的行数
void MainWindow::on_pushButton_2_clicked()
{
    // 读取出spinBox中的数据,并将其设置到表格中
    ui->tableWidget->setRowCount(ui->spinBox->value());

    // 行的底色交替采用不同颜色
    ui->tableWidget->setAlternatingRowColors(true);
}

// 设置表格是否可编辑
void MainWindow::on_checkBox_clicked(bool checked)
{
    if (checked)
        ui->tableWidget->setEditTriggers(QAbstractItemView::DoubleClicked | QAbstractItemView::SelectedClicked);
    else
        ui->tableWidget->setEditTriggers(QAbstractItemView::NoEditTriggers); //不允许编辑
}

// 行的底色交替采用不同颜色
void MainWindow::on_checkBox_2_clicked(bool checked)
{
    ui->tableWidget->setAlternatingRowColors(checked);
}

// 显示水平表头
void MainWindow::on_checkBox_3_clicked(bool checked)
{
    ui->tableWidget->horizontalHeader()->setVisible(checked);
}

// 显示垂直表头
void MainWindow::on_checkBox_4_clicked(bool checked)
{
    ui->tableWidget->verticalHeader()->setVisible(checked);
}

// 设置为单元格选择
void MainWindow::on_radioButton_clicked()
{
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectItems);
}

// 设置为行选择
void MainWindow::on_radioButton_2_clicked()
{
    ui->tableWidget->setSelectionBehavior(QAbstractItemView::SelectRows);
}

// 实现自适应调节行高与列宽
void MainWindow::on_pushButton_3_clicked()
{
    // 调节行高
    ui->tableWidget->resizeRowsToContents();

    // 调节列宽
    ui->tableWidget->resizeColumnsToContents();
}

// 在所选单元上面插入一行数据
void MainWindow::on_pushButton_5_clicked()
{
    int CurRow = ui->tableWidget->currentRow();      // 获取当前行号
    ui->tableWidget->insertRow(CurRow);              // 插入行,但不会自动创建Item

    // 调用插入函数
    createItemsARow(CurRow,"插入新生","男",QDate::fromString("2010-12-11","yyyy-M-d"),"苗族",true,87);
}

// 在表格尾部追加行
void MainWindow::on_pushButton_6_clicked()
{
    int curRow=ui->tableWidget->rowCount();                   // 当前行尾部计数
    ui->tableWidget->insertRow(curRow);                       // 在表格尾部添加一行
    createItemsARow(curRow, "追加新生", "女",QDate::fromString("2000-1-1","yyyy-M-d"),"满族",false,50);
}

// 删除选中的一行元素
void MainWindow::on_pushButton_7_clicked()
{
    int curRow=ui->tableWidget->currentRow();     // 当前行号
    ui->tableWidget->removeRow(curRow);           // 删除当前行及其items
}

// 将表格中的数据读入文本框: 将QTableWidget的所有行的内容提取字符串
void MainWindow::on_pushButton_8_clicked()
{
    QString str;
    QTableWidgetItem *cellItem;

    ui->textEdit->clear();         // 先清空一下

    // 循环次数为表格行数,逐行处理
    for(int i=0;i< ui->tableWidget->rowCount();i++)
    {
        str = QString::asprintf("第 %d 行: ",i+1);    // 设置表个第0列

        // 逐列处理,但最后一列是check型,需要单独处理
        for (int j=0;j<ui->tableWidget->columnCount()-1;j++)
        {
            cellItem = ui->tableWidget->item(i,j);     // 获取到单元格的Item
            str = str + cellItem->text() + " | ";      // 连接字符串
        }

        // 最后一列的党员状态,是一个选择框,要单独判断
        cellItem = ui->tableWidget->item(i,colPartyM);

        // 根据选择框的状态来单独判断
        if(cellItem->checkState() == Qt::Checked)
            str = str + "党员";
        else
            str = str + "群众";

        // 添加到编辑框作为一行
        // ui->textEdit->appendPlainText(str);
        ui->textEdit->append(str);
    }
}
