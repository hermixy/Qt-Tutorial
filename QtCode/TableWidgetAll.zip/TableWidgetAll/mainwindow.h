#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <QTextEdit>
#include <QTableWidgetItem>
#include <QTableWidget>
#include <QComboBox>
#include <QTextBlock>
#include <QTextDocument>
#include <iostream>
#include <QString>
#include <QDate>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // 自定义单元格Type的类型，在创建单元格的Item时使用
    enum CellType{ctName=0,ctSex,ctBirth,ctNation,ctPartyM,ctScore};

    // 各字段在表格中的列号
    enum FieldColNum{colName=0, colSex,colBirth,colNation,colScore,colPartyM};

    QLabel  *labCellIndex; // 状态栏上用于显示单元格的行号、列号
    QLabel  *labCellType;  // 状态栏上用于显示单元格的type
    QLabel  *labStudID;    // 状态栏上用于显示单元格的data,

private slots:

    void createItemsARow(int rowNo,QString Name,QString Sex,QDate birth,QString Nation,bool isPM,int score);
    void on_tableWidget_currentCellChanged(int currentRow, int currentColumn, int previousRow, int previousColumn);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_checkBox_clicked(bool checked);

    void on_checkBox_2_clicked(bool checked);

    void on_checkBox_3_clicked(bool checked);

    void on_checkBox_4_clicked(bool checked);

    void on_radioButton_clicked();

    void on_radioButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

    void on_pushButton_5_clicked();

    void on_pushButton_6_clicked();

    void on_pushButton_7_clicked();

    void on_pushButton_8_clicked();

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
