#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dialog.h"
#include <iostream>
#include <QDialog>

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit->setEnabled(false);
    ui->lineEdit->setText("hello lyshark");
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 按钮点击后执行
void MainWindow::on_pushButton_clicked()
{
    // 创建模态对话框
    Dialog *ptr = new Dialog(this);                                 // 创建一个对话框
    Qt::WindowFlags flags = ptr->windowFlags();                     // 需要获取返回值
    ptr->setWindowFlags(flags | Qt::MSWindowsFixedSizeDialogHint);  // 设置对话框固定大小

    // 读取MainWindows参数并设置到Dialog
    QString item = ui->lineEdit->text();
    ptr->SetValue(item);

    int ref = ptr->exec();             // 以模态方式显示对话框
    if (ref==QDialog::Accepted)        // OK键被按下,对话框关闭
    {
        // 当BtnOk被按下时,则设置对话框中的数据
        QString the_value = ptr->GetValue();
        std::cout << "value = " << the_value.toStdString().data() << std::endl;
        ui->lineEdit->setText(the_value);
    }

    // 删除释放对话框句柄
    delete ptr;
}
