#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :QDialog(parent),ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

// 用于MainWindow获取编辑框中的数据
QString Dialog::GetValue()
{
    return ui->lineEdit->text();
}

// 用于设置当前编辑框中的数据为MainWindow
void Dialog::SetValue(QString x)
{
    ui->lineEdit->setText(x);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::on_BtnOk_clicked()
{

}

void Dialog::on_BtnCancel_clicked()
{

}
