#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLabel>
#include <iostream>

#include <QStandardItem>
#include <QStandardItemModel>
#include <QItemSelectionModel>

#include "spindelegate.h"
#include "comboxdelegate.h"
#include "floatspindelegate.h"

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private:
    Ui::MainWindow *ui;

    QStandardItemModel *model;         // 定义数据模型
    QItemSelectionModel *selection;    // 定义Item选择模型

    // 代理组件的使用
    QWIntSpinDelegate intSpinDelegate;      // 定义整型代理
    QWFloatSpinDelegate floatSpinDelegate;  // 定义浮点数代理
    QWComboBoxDelegate comboBoxDelegate;    // 定义列表选择代理
};
#endif // MAINWINDOW_H
