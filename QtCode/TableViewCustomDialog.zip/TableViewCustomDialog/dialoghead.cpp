#include "dialoghead.h"
#include "ui_dialoghead.h"

DialogHead::DialogHead(QWidget *parent) :QDialog(parent),ui(new Ui::DialogHead)
{
    ui->setupUi(this);
    model = new QStringListModel;
    ui->listView->setModel(model);
}

DialogHead::~DialogHead()
{
    delete ui;
}

// 设置当前listView中的数据
void DialogHead::setHeaderList(QStringList &headers)
{
    model->setStringList(headers);
}
// 返回当前的表头
QStringList DialogHead::headerList()
{
    return model->stringList();
}
