#ifndef DIALOGHEAD_H
#define DIALOGHEAD_H

#include <QDialog>
#include <QStringListModel>

namespace Ui {
class DialogHead;
}

class DialogHead : public QDialog
{
    Q_OBJECT

public:
    explicit DialogHead(QWidget *parent = nullptr);
    ~DialogHead();

    void setHeaderList(QStringList& headers);   // 设置表头数据
    QStringList headerList();                   // 返回表头数据
private:
    QStringListModel *model;       // 定义数据模型
    Ui::DialogHead *ui;
};

#endif // DIALOGHEAD_H
