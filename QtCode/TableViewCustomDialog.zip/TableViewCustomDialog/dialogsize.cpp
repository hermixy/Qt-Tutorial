#include "dialogsize.h"
#include "ui_dialogsize.h"

DialogSize::DialogSize(QWidget *parent) :QDialog(parent),ui(new Ui::DialogSize)
{
    ui->setupUi(this);
}

DialogSize::~DialogSize()
{
    delete ui;
}

// 主窗体调用获取当前行数
int DialogSize::rowCount()
{
    return  ui->spinBoxRow->value();
}

// 主窗体调用获取当前列数
int DialogSize::columnCount()
{
    return  ui->spinBoxColumn->value();
}

// 设置主窗体中的TableView行数与列数
void DialogSize::setRowColumn(int row, int column)
{
    ui->spinBoxRow->setValue(row);
    ui->spinBoxColumn->setValue(column);
}

