#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dialogsize.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    model = new QStandardItemModel(4,5,this);
    selection = new QItemSelectionModel(model);

    // 关联到tableView
    ui->tableView->setModel(model);
    ui->tableView->setSelectionModel(selection);

    // 关联到treeView
    ui->treeView->setModel(model);
    ui->treeView->setSelectionModel(selection);

    // 添加表头
    QStringList HeaderList;
    HeaderList << "序号" << "姓名" << "年龄" << "性别" << "婚否";
    model->setHorizontalHeaderLabels(HeaderList);

    // 批量添加数据
    QStringList DataList[3];
    QStandardItem *Item;

    DataList[0] << "1001" << "admin" << "24" << "男" << "是";
    DataList[1] << "1002" << "lyshark" << "23" << "男" << "否";
    DataList[2] << "1003" << "lucy" << "37" << "女" << "是";

    int Array_Length = DataList->length();                          // 获取每个数组中元素数
    int Array_Count = sizeof(DataList) / sizeof(DataList[0]);       // 获取数组个数

    for(int x=0; x<Array_Count; x++)
    {
        for(int y=0; y<Array_Length; y++)
        {
            Item = new QStandardItem(DataList[x][y]);
            model->setItem(x,y,Item);
        }
    }
}



MainWindow::~MainWindow()
{
    delete ui;
}

// 当按钮1被点击触发
void MainWindow::on_pushButton_clicked()
{
    // //模态对话框，动态创建，用过后删除
    DialogSize *ptr = new DialogSize(this);     // 创建一个对话框
    Qt::WindowFlags flags = ptr->windowFlags(); // 需要获取返回值
    ptr->setWindowFlags(flags | Qt::MSWindowsFixedSizeDialogHint);  // 设置对话框固定大小
    ptr->setRowColumn(model->rowCount(),model->columnCount());      // 对话框数据初始化

    int ref = ptr->exec();             // 以模态方式显示对话框
    if (ref==QDialog::Accepted)        // OK键被按下,对话框关闭
    {
        // 当BtnOk被按下时,则设置对话框中的数据
        int cols=ptr->columnCount();
        model->setColumnCount(cols);

        int rows=ptr->rowCount();
        model->setRowCount(rows);
    }

    // 最后删除释放对话框句柄
    delete ptr;
}

// 对话框设置表头数据
void MainWindow::on_pushButton_2_clicked()
{
    DialogHead *ptr = new DialogHead(this);
    Qt::WindowFlags flags = ptr->windowFlags();
    ptr->setWindowFlags(flags | Qt::MSWindowsFixedSizeDialogHint);

    // 如果表头列数变化,则从新初始化
    if(ptr->headerList().count() != model->columnCount())
    {
        QStringList strList;

        // 获取现有的表头标题
        for (int i=0;i<model->columnCount();i++)
        {
            strList.append(model->headerData(i,Qt::Horizontal,Qt::DisplayRole).toString());
        }

        // 用于对话框初始化显示
        ptr->setHeaderList(strList);
    }

    int ref = ptr->exec();  // 调用弹窗
    if(ref==QDialog::Accepted)
    {
        QStringList strList=ptr->headerList();//获取对话框上修改后的StringList
        model->setHorizontalHeaderLabels(strList);// 设置模型的表头标题
    }

    delete ptr;
}
