#ifndef DIALOGSIZE_H
#define DIALOGSIZE_H

#include <QDialog>

namespace Ui {
class DialogSize;
}

class DialogSize : public QDialog
{
    Q_OBJECT

public:
    explicit DialogSize(QWidget *parent = nullptr);
    ~DialogSize();

    int rowCount();                         // 获取对话框输入的行数
    int columnCount();                      // 获取对话框输入的列数
    void setRowColumn(int row, int column);  // 初始对话框上两个SpinBox的值

private:
    Ui::DialogSize *ui;
};

#endif // DIALOGSIZE_H
