#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>

#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QIcon>
#include <QMenu>
#include <iostream>
#include <QIcon>
#include <QString>

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

    // 全局下设置增加删除菜单
    QAction *GetColumnAction;
    QAction *GetRowDataAction;
    QAction *GetLineAction;

private slots:
    void on_treeWidget_customContextMenuRequested(const QPoint &pos);

private:
    Ui::MainWindow *ui;
};
#endif // MAINWINDOW_H
