#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    // 在MainWindow中使用右击菜单需要添加此项
    ui->treeWidget->setContextMenuPolicy(Qt::CustomContextMenu);

    // 创建基础顶部菜单
    QMenuBar *bar = menuBar();
    this->setMenuBar(bar);
    QMenu * fileMenu = bar->addMenu("菜单1");

    // 实现只隐藏菜单1其他的不受影响
    fileMenu->menuAction()->setVisible(false);

    // 添加子菜单
    GetColumnAction = fileMenu->addAction("获取列号");
    GetRowDataAction = fileMenu->addAction("获取本行数据");
    GetLineAction = fileMenu->addAction("获取行号");

    // 分别设置图标
    GetColumnAction->setIcon(QIcon(":/image/1.ico"));
    GetRowDataAction->setIcon(QIcon(":/image/2.ico"));
    GetLineAction->setIcon(QIcon(":/image/3.ico"));

    // 为子菜单绑定热键
    GetColumnAction->setShortcut(Qt::CTRL | Qt::Key_A);
    GetRowDataAction->setShortcut(Qt::SHIFT | Qt::Key_S);
    GetLineAction->setShortcut(Qt::CTRL | Qt::SHIFT | Qt::Key_B);

    // 绑定槽函数: 获取选中列
    connect(GetColumnAction,&QAction::triggered,this,[=](){
        int col = ui->treeWidget->currentColumn();
        std::cout << col << std::endl;
    });

    // 绑定槽函数: 获取选中的第0行的数据内容
    connect(GetRowDataAction,&QAction::triggered,this,[=](){
        QString msg = ui->treeWidget->currentItem()->text(0);
        std::cout << msg.toStdString().data() << std::endl;
    });

    // 绑定槽函数: 获取当前选中的索引值
    connect(GetLineAction,&QAction::triggered,this,[=](){
        int row  = ui->treeWidget->currentIndex().row();
        std::cout << row << std::endl;
    });

    // 设置treeWidget属性
    ui->treeWidget->setColumnCount(4);         // 设置总列数
    ui->treeWidget->setColumnWidth(0,300);     // 设置最后一列宽度自适应
    ui->treeWidget->setIndentation(1);         // 设置表头缩进为1

    // 设置表头数据
    QStringList headers;
    headers.append("文件名");
    headers.append("更新时间");
    headers.append("文件类型");
    headers.append("文件大小");
    ui->treeWidget->setHeaderLabels(headers);

    // 模拟插入数据到表中
    for(int x=0;x<100;x++)
    {
        QTreeWidgetItem* item=new QTreeWidgetItem();
        item->setText(0,"<lyshark.com>");
        item->setIcon(0,QIcon(":/image/1.ico"));
        item->setText(1,"2020-12-11");
        item->setText(2,"*.pdf");
        item->setText(3,"102MB");
        item->setIcon(3,QIcon(":/image/2.ico"));
        ui->treeWidget->addTopLevelItem(item);
    }
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 当treeWidget中的右键被点击时则触发
void MainWindow::on_treeWidget_customContextMenuRequested(const QPoint &pos)
{
    std::cout << "x pos = "<< pos.x() << "y pos = " << pos.y() << std::endl;
    Q_UNUSED(pos);

    // 新建Menu菜单
    QMenu *ptr = new QMenu(this);

    // 添加Actions创建菜单项
    ptr->addAction(GetColumnAction);
    ptr->addAction(GetLineAction);

    // 添加一个分割线
    ptr->addSeparator();
    ptr->addAction(GetRowDataAction);

    // 在鼠标光标位置显示右键快捷菜单
    ptr->exec(QCursor::pos());
    // 手工创建的指针必须手工删除
    delete ptr;
}
