#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <iostream>

#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSqlRecord>

#include <QtSql>
#include <QDataWidgetMapper>

QSqlDatabase DB;                     // 数据库连接
QSqlRelationalTableModel *tabModel;  // 数据模型
QItemSelectionModel *theSelection;   // 选择模型

// 初始化数据表
void MainWindow::InitSQL()
{
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("./database.db");
    if (!db.open())
           return;

    // 执行SQL创建表
    db.exec("DROP TABLE Student");
    db.exec("CREATE TABLE Student ("
                   "id INTEGER PRIMARY KEY AUTOINCREMENT, "
                   "name VARCHAR(40) NOT NULL, "
                   "departID INTEGER NOT NULL)"
            );

    // 逐条插入数据
    db.exec("INSERT INTO Student(name,departID) VALUES('zhangsan',10)");
    db.exec("INSERT INTO Student(name,departID) VALUES('lisi',20)");
    db.exec("INSERT INTO Student(name,departID) VALUES('wangwu',30)");
    db.exec("INSERT INTO Student(name,departID) VALUES('wangmazi',40)");

    db.exec("DROP TABLE Departments");
    db.exec("CREATE TABLE Departments("
            "departID INTEGER NOT NULL,"
            "department VARCHAR(40) NOT NULL)"
            );

    db.exec("INSERT INTO Departments(departID,department) VALUES (10,'数学学院')");
    db.exec("INSERT INTO Departments(departID,department) VALUES (20,'物理学院')");
    db.exec("INSERT INTO Departments(departID,department) VALUES (30,'计算机学院')");
}




MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    InitSQL();

    // 打开数据库
    QSqlDatabase db = QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("./database.db");
    if (!db.open())
        return;

    this->setCentralWidget(ui->tableView);
    ui->tableView->setSelectionBehavior(QAbstractItemView::SelectItems);
    ui->tableView->setSelectionMode(QAbstractItemView::SingleSelection);
    ui->tableView->setAlternatingRowColors(true);

    //打开数据表
    tabModel=new QSqlRelationalTableModel(this,DB);
    tabModel->setTable("Student");                              // 设置数据表
    tabModel->setEditStrategy(QSqlTableModel::OnManualSubmit);  // OnManualSubmit
    tabModel->setSort(0,Qt::AscendingOrder);

    tabModel->setHeaderData(0,Qt::Horizontal,"学号");
    tabModel->setHeaderData(1,Qt::Horizontal,"姓名");
    tabModel->setHeaderData(2,Qt::Horizontal,"学院");

    // 设置代码字段的查询关系数据表
    // 打开Departments表,关联ID和department
    tabModel->setRelation(2,QSqlRelation("Departments","departID","department"));
    theSelection=new QItemSelectionModel(tabModel);

    ui->tableView->setModel(tabModel);
    ui->tableView->setSelectionModel(theSelection);
    ui->tableView->setItemDelegate(new QSqlRelationalDelegate(ui->tableView)); // 为关系型字段设置缺省代理组件

    tabModel->select();                                                        // 打开数据表
}

MainWindow::~MainWindow()
{
    delete ui;
}

