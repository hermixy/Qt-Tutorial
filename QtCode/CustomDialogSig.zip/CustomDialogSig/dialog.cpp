#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :QDialog(parent),ui(new Ui::Dialog)
{
    ui->setupUi(this);
    connect(ui->pushButton, SIGNAL(clicked()), this, SLOT(onBtnClick()));
}

Dialog::~Dialog()
{
    delete ui;
}

// 发送信号到MainWindow
void Dialog::on_pushButton_clicked()
{
    QString send_data = ui->lineEdit->text();
    emit sendText(send_data);
}
