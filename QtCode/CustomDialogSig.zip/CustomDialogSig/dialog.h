#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = nullptr);
    ~Dialog();

private:
    Ui::Dialog *ui;


// 定义信号(信号只需声明无需实现)
signals:
    void sendText(QString str);

private slots:
    void on_pushButton_clicked();
};

#endif // DIALOG_H
