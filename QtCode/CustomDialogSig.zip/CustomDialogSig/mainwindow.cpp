#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "dialog.h"
#include <QDialog>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->lineEdit->setEnabled(false);
}

// 接收信号并设置到LineEdit上
void MainWindow::receiveMsg(QString str)
{
    ui->lineEdit->setText(str);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_pushButton_clicked()
{
    Dialog *subwindow = new Dialog(this);
    // 当收到sendText信号时使用receiveMsg槽函数处理
    connect(subwindow, SIGNAL(sendText(QString)), this, SLOT(receiveMsg(QString)));
    subwindow->show();
}
