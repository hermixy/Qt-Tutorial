#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->treeWidget->clear();

    // 设置QTreeWidget的列数
    ui->treeWidget->setColumnCount(1);
    // 设置QTreeWidget标题隐藏
    ui->treeWidget->setHeaderHidden(true);

    // 创建QTreeWidget的朋友节点,父节点是tree
    QTreeWidgetItem *Friend = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("朋友")));
    Friend->setIcon(0,QIcon(":/image/4.ico"));  // 添加一个图标
    Friend->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable
                     | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);
    Friend->setCheckState(0,Qt::Checked);

    // 给Friend添加一个子节点frd
    QTreeWidgetItem *frd = new QTreeWidgetItem(Friend);
    frd->setText(0,"老张");
    frd->setIcon(0,QIcon(tr(":/image/1.ico")));
    frd->setCheckState(0,Qt::Checked);               // 默认选中状态

    QTreeWidgetItem *frs = new QTreeWidgetItem(Friend);
    frs->setText(0,"老王");
    frs->setIcon(0,QIcon(tr(":/image/1.ico")));
    frs->setCheckState(0,Qt::Unchecked);            // 默认未选中

    // ----------------------------------------------------------
    // 创建名叫同学节点,父节点同样是tree
    QTreeWidgetItem * ClassMate = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("同学")));
    ClassMate->setIcon(0,QIcon(":/image/5.ico"));  // 添加一个图标
    ClassMate->setCheckState(0,Qt::Checked);       // 默认选中

    //Fly是ClassMate的子节点
    QTreeWidgetItem *Fly = new QTreeWidgetItem(QStringList(QString("张三")));
    Fly->setIcon(0,QIcon(tr(":/image/2.ico")));
    //创建子节点的另一种方法
    ClassMate->addChild(Fly);
    Fly->setCheckState(0,Qt::Checked);       // 设置为选中

    QTreeWidgetItem *Fls = new QTreeWidgetItem(QStringList(QString("李四")));
    Fls->setIcon(0,QIcon(tr(":/image/2.ico")));
    ClassMate->addChild(Fls);
    Fls->setCheckState(0,Qt::Checked);       // 设置为选中

    // ----------------------------------------------------------
    // 陌生人单独一栏
    QTreeWidgetItem  *Strange = new QTreeWidgetItem(true);
    Strange->setText(0,"陌生人");
    Strange->setIcon(0,QIcon(":/image/6.ico"));  // 添加一个图标

    ui->treeWidget->addTopLevelItem(ClassMate);
    ui->treeWidget->addTopLevelItem(Strange);

    //展开QTreeWidget的所有节点
    //ui->treeWidget->expandAll();
    //ui->treeWidget->resize(271,401);
}

MainWindow::~MainWindow()
{
    delete ui;
}

QTreeWidgetItem * MainWindow::AddTreeRoot(QString name,QString desc)
{
    QTreeWidgetItem * item=new QTreeWidgetItem(QStringList()<<name<<desc);
    ui->treeWidget->addTopLevelItem(item);
    return item;
}

QTreeWidgetItem * MainWindow::AddTreeNode(QTreeWidgetItem *parent,QString name,QString desc)
{
    QTreeWidgetItem * item=new QTreeWidgetItem(QStringList()<<name<<desc);
    parent->addChild(item);
    return item;
}

// 当我们双击指定的成员时获取到该成员的名字
void MainWindow::on_treeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    QString str = item->text(column);
    std::cout << str.toStdString().data() << std::endl;
}

// 当我们单击指定成员时获取数据
void MainWindow::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    QString str = item->text(column);
    std::cout << str.toStdString().data() << std::endl;
}

// 单击按钮添加新的父节点
void MainWindow::on_pushButton_clicked()
{
    QString NodeText = "新的父节点";
    QTreeWidgetItem  *item = new QTreeWidgetItem(true);
    item->setText(0,NodeText);
    item->setIcon(0,QIcon(":/image/7.ico"));
    ui->treeWidget->addTopLevelItem(item);
}

// 单击按钮添加子节点
void MainWindow::on_pushButton_4_clicked()
{
    QTreeWidgetItem * item= ui->treeWidget->currentItem();
        if(item!=NULL)
            AddTreeNode(item,"新子节点","新子节点");
        else
            AddTreeRoot("新子节点","新子节点");
}

// 单击后将指定节点修改为Modify并将图标设置为新的
void MainWindow::on_pushButton_2_clicked()
{
    // 得到当前节点
    QTreeWidgetItem *currentItem = ui->treeWidget->currentItem();
    if(currentItem == NULL)
        return;
    // 修改选中项
    for(int x=0;x<currentItem->columnCount();x++)
    {
        currentItem->setText(x,tr("Modify") + QString::number(x));
        currentItem->setIcon(x,QIcon(":/image/1.ico"));
    }

}

// 删除选中的节点
void MainWindow::on_pushButton_3_clicked()
{
    QTreeWidgetItem *currentItem = ui->treeWidget->currentItem();
    if(currentItem == NULL)
        return;

    // 如果没有父节点则直接删除
    if(currentItem->parent() == NULL)
    {
        delete ui->treeWidget->takeTopLevelItem(ui->treeWidget->currentIndex().row());
        std::cout << ui->treeWidget->currentIndex().row() << std::endl;
    }
    else
    {
        // 如果有父节点就要用父节点的takeChild删除节点
        delete currentItem->parent()->takeChild(ui->treeWidget->currentIndex().row());
    }
}

// 枚举所有节点
void MainWindow::on_pushButton_5_clicked()
{
    // 获取到全部的根节点数量
    int size = ui->treeWidget->topLevelItemCount();
    QTreeWidgetItem *child;
    for(int x=0;x<size;x++)
    {
        // 输出所有父节点
        child = ui->treeWidget->topLevelItem(x);
        std::cout << "all root = "<< child->text(0).toStdString().data() << std::endl;

        // 得到所有子节点计数
        int childCount = child->childCount();
        // std::cout << "all child count = " << childCount << std::endl;

        // 输出根节点下面的子节点
        for(int y=0;y<childCount;++y)
        {
            QTreeWidgetItem *grandson = child->child(y);
            std::cout << "--> sub child = "<< grandson->text(0).toStdString().data() << std::endl;

        }
    }
}

// 获取子节点的父节点ID,然后根据ID得到子节点名字
void MainWindow::on_pushButton_6_clicked()
{
    // 取所有的父节点
    QTreeWidgetItem *currentItem = ui->treeWidget->currentItem()->parent();
    int root_count = ui->treeWidget->indexOfTopLevelItem(currentItem);
    std::cout << "root Count = " <<  root_count << std::endl;
    if(root_count != -1)
    {
        // 指定序号对应的父节点名字
        QTreeWidgetItem *child;

        child = ui->treeWidget->topLevelItem(root_count);
        std::cout << "root name= "<< child->text(0).toStdString().data() << std::endl;
    }
}

// 枚举所有的 【选中】节点
void MainWindow::on_pushButton_7_clicked()
{
    // 获取到全部的根节点数量
    int size = ui->treeWidget->topLevelItemCount();
    QTreeWidgetItem *child;
    for(int x=0;x<size;x++)
    {
        // 输出所有父节点
        child = ui->treeWidget->topLevelItem(x);

        // 得到所有子节点计数
        int childCount = child->childCount();

        // 输出根节点下面的子节点
        for(int y=0;y<childCount;++y)
        {
            QTreeWidgetItem *grandson = child->child(y);
            // 判断是否选中,如果选中输出父节点与子节点
            if(Qt::Checked == grandson->checkState(0))
            {
                std::cout << "root -> " << child->text(0).toStdString().data()
                          << "--> sub child = "<< grandson->text(0).toStdString().data() << std::endl;
            }
        }
    }
}
