﻿#include "mainwindow.h"
#include "ui_mainwindow.h"


MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    model=new QFileSystemModel(this);          // QFileSystemModel提供单独线程
    model->setRootPath(QDir::currentPath());   // 设置根目录

    QStringList filter;                        // 设置过滤器,只过滤出txt,mp4
    filter << "*.txt" << "*.mp4";

    model->setNameFilters(filter);             // 使用过滤器
    model->setNameFilterDisables(false);

    ui->treeView->setModel(model);     // 设置数据模型
    ui->listView->setModel(model);     // 设置数据模型
    ui->tableView->setModel(model);    // 设置数据模型
	
	ui->listView->setViewMode(QListView::IconMode);    // 设置listView图标显示

// 信号与槽关联，treeView单击时，其目录设置为listView和tableView的根节点
    connect(ui->treeView,SIGNAL(clicked(QModelIndex)),ui->listView,SLOT(setRootIndex(QModelIndex)));
    connect(ui->treeView,SIGNAL(clicked(QModelIndex)),ui->tableView,SLOT(setRootIndex(QModelIndex)));
}

MainWindow::~MainWindow()
{
    delete ui;
}

// TreeView被点击后触发
void MainWindow::on_treeView_clicked(const QModelIndex &index)
{
    ui->chkIsDir->setChecked(model->isDir(index));
    ui->LabPath->setText(model->filePath(index));
    ui->LabType->setText(model->type(index));

    ui->LabFileName->setText(model->fileName(index));

    int sz=model->size(index)/1024;
    if (sz<1024)
        ui->LabFileSize->setText(QString("%1 KB").arg(sz));
    else
        ui->LabFileSize->setText(QString::asprintf("%.1f MB",sz/1024.0));
}
