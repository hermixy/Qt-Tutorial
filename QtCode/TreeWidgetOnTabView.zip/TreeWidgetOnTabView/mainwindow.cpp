#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QStyleFactory>

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->treeWidget->clear();

    ui->treeWidget->setColumnCount(1);
    ui->treeWidget->setHeaderHidden(true);
    ui->tabWidget->tabBar()->hide();
    // 增加线条
    ui->treeWidget->setStyle(QStyleFactory::create("windows"));

// ----------------------------------------------------------
    // 创建 [系统设置] 父节点
    QTreeWidgetItem *system_setup = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("系统位置")));
    system_setup->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);

    // 给父节点添加子节点
    QTreeWidgetItem *system_setup_child_node_1 = new QTreeWidgetItem(system_setup);
    system_setup_child_node_1->setText(0,"修改密码");
    QTreeWidgetItem *system_setup_child_node_2 = new QTreeWidgetItem(system_setup);
    system_setup_child_node_2->setText(0,"设置菜单");

// ----------------------------------------------------------
    // 创建 [页面布局] 父节点
    QTreeWidgetItem *page_layout = new QTreeWidgetItem(ui->treeWidget,QStringList(QString("页面布局")));
    page_layout->setFlags(Qt::ItemIsSelectable | Qt::ItemIsUserCheckable | Qt::ItemIsEnabled | Qt::ItemIsAutoTristate);

    QTreeWidgetItem *page_layout_clild_1 = new QTreeWidgetItem(page_layout);
    page_layout_clild_1->setText(0,"页面配置");
    QTreeWidgetItem *page_layout_clild_2 = new QTreeWidgetItem(page_layout);
    page_layout_clild_2->setText(0,"页面参数");

    ui->treeWidget->expandAll();
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 当treeWidget空间双击后根据不同的菜单项选择不同的TabView页
void MainWindow::on_treeWidget_itemDoubleClicked(QTreeWidgetItem *item, int column)
{
    QString str = item->text(column);

    if(str == "修改密码")
    {
        ui->tabWidget->setCurrentIndex(0);
    }
    if(str == "设置菜单")
    {
        ui->tabWidget->setCurrentIndex(1);
    }
    if(str == "页面配置")
    {
        ui->tabWidget->setCurrentIndex(2);
    }
    if(str == "页面参数")
    {
        ui->tabWidget->setCurrentIndex(3);
    }
}
