#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :QDialog(parent),ui(new Ui::Dialog)
{
    ui->setupUi(this);

    this->setWindowTitle("New Doc");           // 窗口标题
    this->setAttribute(Qt::WA_DeleteOnClose);  // 关闭时自动删除
    this->setFixedSize(200,100);               // 设置窗体大小
    // this->setWindowIcon(QIcon(":/image/1.ico"));
}

Dialog::~Dialog()
{
    delete ui;
}

// 获取窗体标题
QString Dialog::currentFileName()
{
    QString title = this->windowTitle();
    return title;
}

// 设置编辑框内容
void Dialog::SetData(QString data)
{
    ui->lineEdit->setText(data);
}
