#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMdiSubWindow>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    void closeEvent(QCloseEvent *event);

private slots:
    void on_actionOpen_triggered();
    void on_actionClose_triggered();
    void on_actionMID_triggered(bool checked);
    void on_actionLine_triggered();
    void on_actionTile_triggered();
    void on_mdiArea_subWindowActivated(QMdiSubWindow *arg1);
    void on_actionWindow_triggered();
    void on_actionSendMsg_triggered();

private:
    Ui::MainWindow *ui;
};

#endif // MAINWINDOW_H
