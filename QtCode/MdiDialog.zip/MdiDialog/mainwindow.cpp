#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "dialog.h"
#include <iostream>
#include <QCloseEvent>

// 如果直接关闭,则清空所有对话框
void MainWindow::closeEvent(QCloseEvent *event)
{
    ui->mdiArea->closeAllSubWindows();
    event->accept();
}

MainWindow::MainWindow(QWidget *parent) :QMainWindow(parent),ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    this->setCentralWidget(ui->mdiArea);
    //this->setWindowState(Qt::WindowMaximized); //窗口最大化显示
    ui->mainToolBar->setToolButtonStyle(Qt::ToolButtonTextUnderIcon);
    ui->mdiArea->setViewMode(QMdiArea::SubWindowView); //子窗口模式
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 新建窗体
void MainWindow::on_actionOpen_triggered()
{
    Dialog *formDoc = new Dialog(this); //
    ui->mdiArea->addSubWindow(formDoc); //文档窗口添加到MDI
    formDoc->show(); //在单独的窗口中显示
}
// 关闭全部
void MainWindow::on_actionClose_triggered()
{
    ui->mdiArea->closeAllSubWindows(); //关闭所有子窗口
}

// 转为MID模式
void MainWindow::on_actionMID_triggered(bool checked)
{
    // Tab多页显示模式
    if (checked)
    {
        ui->mdiArea->setViewMode(QMdiArea::TabbedView); // Tab多页显示模式
        ui->mdiArea->setTabsClosable(true);             // 页面可关闭
        ui->actionLine->setEnabled(false);
        ui->actionTile->setEnabled(false);
    }
    // 子窗口模式
    else
    {
        ui->mdiArea->setViewMode(QMdiArea::SubWindowView); // 子窗口模式
        ui->actionLine->setEnabled(true);
        ui->actionTile->setEnabled(true);
    }
}

// 恢复默认模式
void MainWindow::on_actionWindow_triggered()
{
    ui->mdiArea->setViewMode(QMdiArea::SubWindowView);
    ui->actionLine->setEnabled(true);
    ui->actionMID->setEnabled(true);
    ui->actionTile->setEnabled(true);
}

// 级联模式
void MainWindow::on_actionLine_triggered()
{
    ui->mdiArea->cascadeSubWindows();
}

// 平铺模式
void MainWindow::on_actionTile_triggered()
{
    ui->mdiArea->tileSubWindows();
}

// 当子窗体打开时获取到其窗体标题
void MainWindow::on_mdiArea_subWindowActivated(QMdiSubWindow *arg1)
{
    Q_UNUSED(arg1);

    // 若子窗口个数为零,则将statusBar置空
    if (ui->mdiArea->subWindowList().count()==0)
    {
        ui->statusBar->clearMessage();
    }
    else
    {
        // 如果不为0则显示主窗口的文件名
        Dialog *formDoc=static_cast<Dialog*>(ui->mdiArea->activeSubWindow()->widget());
        ui->statusBar->showMessage(formDoc->currentFileName());
    }
}

// 对选中窗体发送数据
void MainWindow::on_actionSendMsg_triggered()
{
    // 先获取当前MDI子窗口
    Dialog *formDoc;

    // 如果打开则获取活动窗体
    if (ui->mdiArea->subWindowList().count() > 0)
    {
        formDoc=(Dialog*)ui->mdiArea->activeSubWindow()->widget();
        // 对活动窗体设置数据
        formDoc->SetData("hello lyshark");
    }
}
