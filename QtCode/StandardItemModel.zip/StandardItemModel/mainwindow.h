#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <iostream>
#include <QLabel>
#include <QStandardItem>
#include <QItemSelectionModel>

#include <QFileDialog>
#include <QTextStream>

#include <QList>

#define FixedColumnCount 6   // 定义文件固定长度为6列

QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

private slots:
    void on_actionOpen_triggered();
    void on_actionSave_triggered();
    void on_actionView_triggered();
    void on_actionAppend_triggered();
    void on_actionInsert_triggered();
    void on_actionDelete_triggered();


    // 当前选择单元格发生变化,则调用该函数
    void on_currentChanged(const QModelIndex &current, const QModelIndex &previous);

    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_3_clicked();

    void on_pushButton_4_clicked();

private:
    Ui::MainWindow *ui;

    //用于状态栏的信息显示
    QLabel  *LabCurFile;    // 当前文件
    QLabel  *LabCellPos;    // 当前单元格行列号
    QLabel  *LabCellText;   // 当前单元格内容

    QStandardItemModel *model;       // 数据模型
    QItemSelectionModel *selection;  // 定义item选择模型
    void iniModelFromStringList(QStringList&); // 从StringList初始化数据模型
};
#endif // MAINWINDOW_H
