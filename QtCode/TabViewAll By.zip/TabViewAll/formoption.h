#ifndef FORMOPTION_H
#define FORMOPTION_H

#include <QWidget>

namespace Ui {
class FormOption;
}

class FormOption : public QWidget
{
    Q_OBJECT

public:
    explicit FormOption(QWidget *parent = nullptr);
    ~FormOption();

private:
    Ui::FormOption *ui;
};

#endif // FORMOPTION_H
