#include "formoption.h"
#include "ui_formoption.h"

FormOption::FormOption(QWidget *parent) :QWidget(parent),ui(new Ui::FormOption)
{
    ui->setupUi(this);
}

FormOption::~FormOption()
{
    delete ui;
}
