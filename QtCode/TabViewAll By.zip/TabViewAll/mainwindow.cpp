#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <iostream>

#include "formmain.h"
#include "formoption.h"
#include "formcharts.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->tabWidget->setVisible(false);
    ui->tabWidget->clear();        //清除所有页面
    ui->tabWidget->tabsClosable(); //Page有关闭按钮，可被关闭

    ui->tabWidget->setTabPosition(QTabWidget::North);       // 设置选项卡方位
    ui->tabWidget->setIconSize(QSize(50, 25));              // 设置图标整体大小
    //ui->tabWidget->setTabShape(QTabWidget::Triangular);   // 设置选项卡形状
    ui->tabWidget->setMovable(true);                        // 设置选项卡是否可拖动
    ui->tabWidget->usesScrollButtons();                     // 选项卡滚动

    ui->toolBar->setMovable(false);
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 首页菜单创建
void MainWindow::on_actionMain_triggered()
{
    int tab_count = ui->tabWidget->count();
    int option_count = 0;

    for(int x=0; x < tab_count; x++)
    {
        // 获取出每个菜单的标题
        QString tab_name = ui->tabWidget->tabText(x);

        if(tab_name == "首页菜单")
            option_count = option_count + 1;
    }

    if(option_count < 1)
    {
        FormMain *ptr = new FormMain(this);              // 新建选项卡
        ptr->setAttribute(Qt::WA_DeleteOnClose);         // 关闭时自动销毁

        int cur=ui->tabWidget->addTab(ptr,QString::asprintf("首页菜单"));
        ui->tabWidget->setTabIcon(cur,QIcon(":/image/1.ico"));

        ui->tabWidget->setCurrentIndex(cur);
        ui->tabWidget->setVisible(true);
    }
}

// 创建系统设置菜单
void MainWindow::on_actionOption_triggered()
{
    int tab_count = ui->tabWidget->count();
    int option_count = 0;

    for(int x=0; x < tab_count; x++)
    {
        // 获取出每个菜单的标题
        QString tab_name = ui->tabWidget->tabText(x);

        if(tab_name == "系统设置")
            option_count = option_count + 1;
    }

    // 判断首页菜单是否只有一个,可判断标签个数来识别
    if(option_count < 1)
    {
        FormOption *ptr = new FormOption(this);
        ptr->setAttribute(Qt::WA_DeleteOnClose);

        int cur = ui->tabWidget->addTab(ptr,QString::asprintf("系统设置"));
        ui->tabWidget->setTabIcon(cur,QIcon(":/image/2.ico"));

        ui->tabWidget->setCurrentIndex(cur);
        ui->tabWidget->setVisible(true);
    }
}

// 绘图页面的弹出
void MainWindow::on_actionCharts_triggered()
{
    FormCharts *ptr = new FormCharts(this);

    ptr->setAttribute(Qt::WA_DeleteOnClose);

    int cur = ui->tabWidget->addTab(ptr,QString::asprintf("图形绘制"));
    ui->tabWidget->setTabIcon(cur,QIcon(":/image/3.ico"));

    ui->tabWidget->setCurrentIndex(cur);
    ui->tabWidget->setVisible(true);
}

// 关闭TabWiget时
void MainWindow::on_tabWidget_tabCloseRequested(int index)
{
    if (index<0)
        return;
    QWidget* aForm=ui->tabWidget->widget(index);
    aForm->close();
}
