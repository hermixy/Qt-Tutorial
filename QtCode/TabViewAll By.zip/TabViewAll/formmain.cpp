#include "formmain.h"
#include "ui_formmain.h"

FormMain::FormMain(QWidget *parent) : QWidget(parent),ui(new Ui::FormMain)
{
    ui->setupUi(this);
}

FormMain::~FormMain()
{
    delete ui;
}

void FormMain::on_pushButton_clicked()
{
    QString line = ui->lineEdit->text();

    ui->label->setText(line);


}
