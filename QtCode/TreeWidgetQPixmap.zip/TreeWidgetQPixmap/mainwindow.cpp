#include "mainwindow.h"
#include "ui_mainwindow.h"

MainWindow::MainWindow(QWidget *parent): QMainWindow(parent), ui(new Ui::MainWindow)
{
    ui->setupUi(this);
    ui->treeWidget->clear();

    // 添加表头
    QStringList headers;
    headers.append("文件名称");
    headers.append("完整路径");
    ui->treeWidget->setHeaderLabels(headers);

    // 设置treeWidget属性
    ui->treeWidget->setColumnCount(2);         // 设置总列数
    ui->treeWidget->setIndentation(1);         // 设置表头缩进为1

    ui->label->setAlignment(Qt::AlignCenter);  // 设置label居中显示
}

MainWindow::~MainWindow()
{
    delete ui;
}

// 从一个完整目录名称里，获得最后的文件夹名称
QString MainWindow::getFinalFolderName(const QString &fullPathName)
{
    int cnt=fullPathName.length();            // 字符串长度
    int i=fullPathName.lastIndexOf("/");      // 最后一次出现的位置
    QString str=fullPathName.right(cnt-i-1);  // 获得最后的文件夹的名称
    return str;
}

// 添加一个子节点
void MainWindow::addImageItem(QString RelativePathName, QString FullPathName)
{
    QString NodeText=getFinalFolderName(FullPathName); //获得最后的文件名称
    QTreeWidgetItem *item; //节点

    // 新创建一个子节点
    item=new QTreeWidgetItem();
    item->setIcon(0,QIcon(":/image/1.ico"));
    item->setText(0,RelativePathName);
    item->setText(1,FullPathName);

    // 设置节点Qt::UserRole的Data,存储完整文件名称 需要注意我们存储的是1这个节点
    // 也就是完整路径中的内容,提取时也应该指定为1节点

    item->setData(0,Qt::UserRole,QVariant(RelativePathName));
    item->setData(1,Qt::UserRole,QVariant(FullPathName));
    ui->treeWidget->addTopLevelItem(item);
}

// 点击按钮批量导入图片资源
void MainWindow::on_pushButton_clicked()
{
    // 选择一个文件或多个
    QStringList file = QFileDialog::getOpenFileNames(this,"选择一个或多个文件","","Images(*.jpg)");

    // 判断是否为空,为空则返回
    if(file.isEmpty())
        return;

    // 循环添加新节点
    for(int x=0;x<file.size();++x)
    {
        QString FullPathName = file.at(x);
        QString RelativePathName = getFinalFolderName(FullPathName);
        std::cout << FullPathName.toStdString().data() << std::endl;
        std::cout << RelativePathName.toStdString().data() << std::endl;
        addImageItem(RelativePathName,FullPathName);
    }
}

// 点击按钮测试获取图片路径
void MainWindow::on_pushButton_2_clicked()
{
    QTreeWidgetItem* parItem=ui->treeWidget->currentItem(); //当前节点

    // 获取节点data里存的文件名,由于设置的是1节点,所以提取是必须也为1
    QString FullPathName = parItem->data(1,Qt::UserRole).toString();
    std::cout << "Full Name => " << FullPathName.toStdString().data() << std::endl;

    QString RelativePathName = parItem->data(0,Qt::UserRole).toString();
    std::cout << "Relative Name => " << RelativePathName.toStdString().data() << std::endl;
}

// 自适应显示图片
void MainWindow::on_actZoomFitH_triggered()
{
    // 自适应高度调整
    int H=ui->scrollArea->height();   // 得到scrollArea的高度
    int realH=curPixmap.height();     // 原始图片的实际高度
    pixRatio=float(H)/realH;          // 当前显示比例,必须转换为浮点数
    QPixmap pix_height = curPixmap.scaledToHeight(H-30);   // 图片缩放到指定高度

    //适应宽度显示
    int w=ui->scrollArea->width()-20;   // 得到scrollArea的高度
    int realw=curPixmap.width();        // 原始图片的实际宽度
    pixRatio=float(w)/realw;            // 当前显示比例，必须转换为浮点数
    QPixmap pix_width = curPixmap.scaledToWidth(w-30);

    // 显示到标签中
    ui->label->setPixmap(pix_height);   // 设置Label的PixMap 按高度调整
    //ui->label->setPixmap(pix_width);  // 按宽度调整
}

// 当图片被选中时默认自适应显示
void MainWindow::on_treeWidget_itemClicked(QTreeWidgetItem *item, int column)
{
    QString FilePath = item->data(column,Qt::UserRole).toString();
    std::cout << "FilePath = " << FilePath.toStdString().data() << std::endl;
    curPixmap.load(FilePath);
    on_actZoomFitH_triggered();
}

// 放大图片
void MainWindow::on_pushButton_3_clicked()
{
    pixRatio=pixRatio*1.2;//在当前比例基础上乘以0.8

    int w=pixRatio*curPixmap.width();// 显示宽度
    int h=pixRatio*curPixmap.height();//显示高度

    QPixmap pix=curPixmap.scaled(w,h);//图片缩放到指定高度和宽度，保持长宽比例
    ui->label->setPixmap(pix);
}

// 缩小图片
void MainWindow::on_pushButton_4_clicked()
{
    pixRatio=pixRatio*0.8; //在当前比例基础上乘以0.8

    int w=pixRatio*curPixmap.width();// 显示宽度
    int h=pixRatio*curPixmap.height();//显示高度

    QPixmap pix=curPixmap.scaled(w,h); //图片缩放到指定高度和宽度，保持长宽比例

    ui->label->setPixmap(pix);
}

// 恢复默认值
void MainWindow::on_pushButton_5_clicked()
{
    pixRatio=1;  //恢复显示比例为1
    ui->label->setPixmap(curPixmap);
}

// 循环删除列表元素
void MainWindow::on_pushButton_6_clicked()
{
    int count = ui->treeWidget->topLevelItemCount();
    for(int x=0; x<count; x++)
    {
        QTreeWidgetItem *item = ui->treeWidget->currentItem();
        delete(item);
    }
}
